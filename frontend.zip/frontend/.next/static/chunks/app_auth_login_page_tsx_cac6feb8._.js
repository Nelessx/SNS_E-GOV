(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_login_page_tsx_cac6feb8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_login_page_tsx_cac6feb8._.js",
  "chunks": [
    "static/chunks/_321546a7._.js"
  ],
  "source": "dynamic"
});
