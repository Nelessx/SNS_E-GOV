(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_4139b1f8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_4139b1f8._.js",
  "chunks": [
    "static/chunks/fdeb8_next_dist_e126657a._.js"
  ],
  "source": "dynamic"
});
