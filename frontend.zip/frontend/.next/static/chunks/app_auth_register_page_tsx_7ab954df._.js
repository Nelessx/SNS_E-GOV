(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_register_page_tsx_7ab954df._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_register_page_tsx_7ab954df._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_0c033395._.js",
    "static/chunks/_61c3775d._.js"
  ],
  "source": "dynamic"
});
