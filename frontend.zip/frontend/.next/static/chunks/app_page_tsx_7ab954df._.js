(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_7ab954df._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_7ab954df._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_82a842f4._.js",
    "static/chunks/_1e50a31a._.js"
  ],
  "source": "dynamic"
});
