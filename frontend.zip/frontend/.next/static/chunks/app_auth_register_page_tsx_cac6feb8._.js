(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_register_page_tsx_cac6feb8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_register_page_tsx_cac6feb8._.js",
  "chunks": [
    "static/chunks/_05344075._.js"
  ],
  "source": "dynamic"
});
