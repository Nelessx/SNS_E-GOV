(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_79eee1cf._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_79eee1cf._.js",
  "chunks": [
    "static/chunks/[root of the server]__98144f0b._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f8304777._.js",
    "static/chunks/node_modules__pnpm_0129d1d9._.js",
    "static/chunks/_f42432e1._.js"
  ],
  "source": "dynamic"
});
