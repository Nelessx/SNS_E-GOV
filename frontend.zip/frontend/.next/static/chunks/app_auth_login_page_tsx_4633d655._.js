(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_auth_login_page_tsx_4633d655._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_auth_login_page_tsx_4633d655._.js",
  "chunks": [
    "static/chunks/node_modules__pnpm_beb93490._.js",
    "static/chunks/_17b50824._.js"
  ],
  "source": "dynamic"
});
