(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/_e69f0d32._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/_e69f0d32._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_dfcc448b._.js",
    "static/chunks/fdeb8_next_dist_compiled_84b9d2d2._.js",
    "static/chunks/fdeb8_next_dist_client_daf0f396._.js",
    "static/chunks/fdeb8_next_dist_ba993173._.js",
    "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
  ],
  "source": "entry"
});
