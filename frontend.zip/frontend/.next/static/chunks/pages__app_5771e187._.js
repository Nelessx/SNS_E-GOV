(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__78e90248._.js",
    "static/chunks/545c3_react-dom_1c85ba3a._.js",
    "static/chunks/node_modules__pnpm_f84813a4._.js",
    "static/chunks/[root of the server]__49fd8634._.js"
  ],
  "source": "entry"
});
